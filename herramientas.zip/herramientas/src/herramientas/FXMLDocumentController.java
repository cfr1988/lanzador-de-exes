/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package herramientas;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;

/**
 *
 * @author carlos
 */
public class FXMLDocumentController implements Initializable {
    

    @FXML
    private Button btnNetbeans;
    @FXML
    private Button btnScene;
    @FXML
    private Button btnInno;
    @FXML
    private Button btnMV;
    @FXML
    private Button btnSublime;
    @FXML
    private Button btnAndroid;
    @FXML
    private Button btnEclipse;
    @FXML
    private Button btnNote;
    @FXML
    private Button btnSmooth;
    @FXML
    private Button btnXampp;
    @FXML
    private Button btnDia;
    @FXML
    private Label titulo;
    @FXML
    private Label label;
    @FXML
    private Button btnSharp;
    @FXML
    private Button btnSalir;
    @FXML
    private Button btnStaruml;
    @FXML
    private AnchorPane panel;

    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        //se ejecuta el metodo de iconos al empezar
        imagenes();
        
    }    

    @FXML
    private void abrenetbeans(ActionEvent event) {
        
        //ejecucion de netbeans
        try {
            Runtime netb = Runtime.getRuntime();
            netb.exec("C:\\Program Files\\NetBeans 8.2\\bin\\netbeans64.exe");
        } catch (IOException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @FXML
    private void abrescene(ActionEvent event) {
        
        //ejecucion de scene builder
        try {
            Runtime scbuilder = Runtime.getRuntime();
            scbuilder.exec("C:\\Users\\carlos\\AppData\\Local\\SceneBuilder\\SceneBuilder.exe");
        } catch (IOException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @FXML
    private void abreinno(ActionEvent event) {
        
        //ejecucion de inno setup
        try {
            Runtime inno = Runtime.getRuntime();
            inno.exec("C:\\Program Files (x86)\\Inno Setup 5\\Compil32.exe");
        } catch (IOException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @FXML
    private void abremv(ActionEvent event) {
        
        //ejecucion de oracle mv
        try {
            Runtime mv = Runtime.getRuntime();
            mv.exec("C:\\Program Files\\Oracle\\VirtualBox\\VirtualBox.exe");
        } catch (IOException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @FXML
    private void abresublime(ActionEvent event) {
        
        //ejecucion sublime text
        try {
            Runtime sublime = Runtime.getRuntime();
            sublime.exec("C:\\Program Files\\Sublime Text 3\\sublime_text.exe");
        } catch (IOException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @FXML
    private void abreandroid(ActionEvent event) {
        
        //ejecucion android studio
        try {
            Runtime android = Runtime.getRuntime();
            android.exec("C:\\Program Files\\Android\\Android Studio\\bin\\studio64.exe");
        } catch (IOException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @FXML
    private void abreeclipse(ActionEvent event) {
        
        //ejecucion eclipse
        try {
            Runtime eclipse = Runtime.getRuntime();
            eclipse.exec("C:\\Users\\carlos\\eclipse\\java-oxygen\\eclipse\\eclipse.exe");
        } catch (IOException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @FXML
    private void abrenotepad(ActionEvent event) {
        
        //ejecucion notepad++
        try {
            Runtime note = Runtime.getRuntime();
            note.exec("C:\\Program Files\\Notepad++\\notepad++.exe");
        } catch (IOException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @FXML
    private void abresmooth(ActionEvent event) {
        
        //ejecucion jsmooth
        try {
            Runtime jsmooth = Runtime.getRuntime();
            jsmooth.exec("C:\\Program Files (x86)\\JSmooth 0.9.9-7\\jsmoothgen.exe");
        } catch (IOException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @FXML
    private void abrexampp(ActionEvent event) {
        
        //ejecucion xampp
        try {
            Runtime xampp = Runtime.getRuntime();
            xampp.exec("C:\\xampp\\xampp-control.exe");
        } catch (IOException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @FXML
    private void abredia(ActionEvent event) {
        
        //ejecucion dia
        try {
            Runtime dia = Runtime.getRuntime();
            dia.exec("C:\\Program Files (x86)\\Dia\\bin\\diaw.exe");
        } catch (IOException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @FXML
    private void abresharp(ActionEvent event) {
        
        //ejecucion sharpdevelop
        try {
            Runtime sharp = Runtime.getRuntime();
            sharp.exec("C:\\Program Files (x86)\\SharpDevelop\\4.4\\bin\\SharpDevelop.exe");
        } catch (IOException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

     @FXML
    private void abrestaruml(ActionEvent event) {
        
        //ejecucion staruml
        try {
            Runtime uml = Runtime.getRuntime();
            uml.exec("C:\\Program Files (x86)\\StarUML\\StarUML.exe");
        } catch (IOException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
    
    @FXML
    private void salida(ActionEvent event) {
        
        //salida
        System.exit(0);
    }
    
    private void imagenes(){
        
        //enlaces de imagenes
        URL enlacedia = getClass().getResource("/iconos/Dia.png");
        URL enlacesharp = getClass().getResource("/iconos/Sharpdevelop.png");
        URL enlaceandroid = getClass().getResource("/iconos/android studio.png");
        URL enlaceeclipse = getClass().getResource("/iconos/eclipse.png");
        URL enlaceinno = getClass().getResource("/iconos/inno setup.png");
        URL enlacesmooth = getClass().getResource("/iconos/jsmooth.png");
        URL enlacemv = getClass().getResource("/iconos/mv.png");
        URL enlacenetbeans = getClass().getResource("/iconos/netbeans.png");
        URL enlacenote = getClass().getResource("/iconos/notepad.png");
        URL enlacescene = getClass().getResource("/iconos/scene builder.png");
        URL enlacestaruml = getClass().getResource("/iconos/staruml.png");
        URL enlacesublime = getClass().getResource("/iconos/sublimetext.png");
        URL enlacexampp = getClass().getResource("/iconos/xampp.png");
        URL enlacesalida = getClass().getResource("/iconos/salida.png");
        
        //creacion de objetos imagenes
        Image imagedia = new Image(enlacedia.toString(),50,24,false,true);
        Image imagesharp = new Image(enlacesharp.toString(),50,24,false,true);
        Image imageandroid = new Image(enlaceandroid.toString(),50,24,false,true);
        Image imageclipse = new Image(enlaceeclipse.toString(),50,24,false,true);
        Image imageinno = new Image(enlaceinno.toString(),50,24,false,true);
        Image imagesmooth = new Image(enlacesmooth.toString(),50,24,false,true);
        Image imagemv = new Image(enlacemv.toString(),50,24,false,true);
        Image imagenetbeans = new Image(enlacenetbeans.toString(),50,24,false,true);
        Image imagenote = new Image(enlacenote.toString(),50,24,false,true);
        Image imagescene = new Image(enlacescene.toString(),50,24,false,true);
        Image imagestar = new Image(enlacestaruml.toString(),50,24,false,true);
        Image imagesublime = new Image(enlacesublime.toString(),50,24,false,true);
        Image imagexampp = new Image(enlacexampp.toString(),50,24,false,true);
        Image imagesalir = new Image(enlacesalida.toString(),50,24,false,true);
        
        //asignacion de imagenes a botones
        btnNetbeans.setGraphic(new ImageView(imagenetbeans));
        btnScene.setGraphic(new ImageView(imagescene));
        btnInno.setGraphic(new ImageView(imageinno));
        btnMV.setGraphic(new ImageView(imagemv));
        btnSublime.setGraphic(new ImageView(imagesublime));
        btnAndroid.setGraphic(new ImageView(imageandroid));
        btnEclipse.setGraphic(new ImageView(imageclipse));
        btnNote.setGraphic(new ImageView(imagenote));
        btnSmooth.setGraphic(new ImageView(imagesmooth));
        btnXampp.setGraphic(new ImageView(imagexampp));
        btnDia.setGraphic(new ImageView(imagedia));
        btnSharp.setGraphic(new ImageView(imagesharp));
        btnSalir.setGraphic(new ImageView(imagesalir));
        btnStaruml.setGraphic(new ImageView(imagestar));

    }

   
    
}
